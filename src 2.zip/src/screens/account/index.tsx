import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

const Account = () => {
  return (
    <View>
      <Text>Account</Text>
    </View>
  )
}

export default Account

const styles = StyleSheet.create({})