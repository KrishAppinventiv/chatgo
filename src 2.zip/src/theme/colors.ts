export default {
  black: '#333333',
  red: '#ff0000',
  grey: '#555555',
  textGrey: '#5b5b5b',
  midGrey: '#555555',
  white: '#ffffff',
};
