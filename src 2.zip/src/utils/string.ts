const strings = {
  hello: 'Hello',
  header:'Messages',
contactsNumber:'45 Contacts',
startbutton:"Start Chat",
modalButton1:"New Chat",
modalButton2:"New Group Chat",
modalButton3:"New Announcement",
chatModalButton3:"Search Chat",
chatModalButton2:"Pin Chat",
chatModalButton1:"View Details",
chatModalButton4:"Delete",
chatSubheading:"Clocked In",
chatOp1:'Reply',
chatOp2:'Forward',
chatOp3:'Copy',
chatOp4:'Star',
chatOp5:'Edit',
};

export default strings;
