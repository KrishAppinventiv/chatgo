import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

const Favourite = () => {
  return (
    <View>
      <Text>index</Text>
    </View>
  )
}

export default Favourite

const styles = StyleSheet.create({})