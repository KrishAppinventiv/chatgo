import {View, Text} from 'react-native';
import React from 'react';

const Tutorial = () => {
  return (
    <View>
      <Text>Tutorial</Text>
    </View>
  );
};

export default Tutorial;
